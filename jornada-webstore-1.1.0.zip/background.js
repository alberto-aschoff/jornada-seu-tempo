import {DEFAULTS,FIELDS,dateKey,minute,validate,settingsValid,calculate,reminder,time} from './core.js';
let queue=Promise.resolve();
const serial=fn=>{const result=queue.then(fn);queue=result.catch(console.error);return result;};
async function read(){const {data}=await chrome.storage.local.get('data');return data??{settings:{...DEFAULTS},days:{},sent:{}};}
async function save(data){await chrome.storage.local.set({data});}
async function notify(id,title,message){await chrome.notifications.create(id,{type:'basic',iconUrl:'icons/128.png',title,message,priority:2});}
async function tick(){
 const data=await read(),now=new Date(),key=dateKey(now),day=data.days[key]??{},c=calculate(day,data.settings,minute(now));
 const r=reminder(day,data.settings,minute(now),now.getDay());
 const badge=c.state==='done'?'✓':r&&c.state==='idle'?'!':c.state==='lunch'?'Ⅱ':c.state==='working'?(c.remaining<=0?'✓':c.remaining<=60?String(Math.ceil(c.remaining)):time(c.leave).slice(0,5)):'';
 await chrome.action.setBadgeText({text:badge});
 await chrome.action.setBadgeBackgroundColor({color:c.state==='lunch'?'#ab681d':'#b91c27'});
 await chrome.action.setTitle({title:c.leave!=null?`Jornada · saída ${c.estimated?'estimada ':''}${time(c.leave)}`:'Jornada · aguardando entrada'});
 if(data.settings.notifications&&r&&!data.sent[`${key}:${r.id}`]){
  await notify('jornada-reminder',r.title,r.message);
  data.sent[`${key}:${r.id}`]=true;
  // Retain only today's deduplication keys, while keeping the full day history.
  data.sent=Object.fromEntries(Object.entries(data.sent).filter(([k])=>k.startsWith(key)));
  await save(data);
 }
}
async function ensureAlarm(){if(!await chrome.alarms.get('jornada-tick'))await chrome.alarms.create('jornada-tick',{periodInMinutes:1});}
chrome.runtime.onInstalled.addListener(()=>serial(async()=>{await ensureAlarm();await tick();}));
chrome.runtime.onStartup.addListener(()=>serial(async()=>{await ensureAlarm();await tick();}));
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='jornada-tick')serial(tick);});
chrome.notifications.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('popup.html')}));
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
 if(sender.id!==chrome.runtime.id)return;
 serial(async()=>{
  await ensureAlarm();
  if(msg.type==='read'){await tick();return read();}
  if(msg.type==='test'){await notify('jornada-test','Lembretes ativados','Tudo pronto. Os avisos da sua jornada aparecerão aqui.');return {};}
  const data=await read(),key=dateKey(),now=minute();
  if(msg.type==='settings'){
   if(!settingsValid(msg.settings))throw Error('Revise os ajustes. Jornada: até 16h. Almoço: de 1h a 6h.');
   data.settings=msg.settings;
   if(data.days[key]){data.days[key].work=msg.settings.work;data.days[key].lunch=msg.settings.lunch;}
  }else if(msg.type==='mark'){
   if(msg.date!==key)throw Error('O dia mudou. Reabra a extensão antes de registrar.');
   if(!FIELDS.includes(msg.field))throw Error('Marcação inválida.');
   const day={...data.days[key],work:data.settings.work,lunch:data.settings.lunch};
   if((day[msg.field]??null)!==msg.expected)throw Error('Esse horário mudou em outra janela. Confira e tente novamente.');
   day[msg.field]=msg.value;
   const error=validate(day,now);if(error)throw Error(error);
   data.days[key]=day;
  }else if(msg.type==='marks'){
   if(msg.date!==key)throw Error('O dia mudou. Reabra a extensão antes de registrar.');
   const day={...data.days[key],work:data.settings.work,lunch:data.settings.lunch};
   for(const f of FIELDS)day[f]=msg.marks[f]??null;
   const error=validate(day,now);if(error)throw Error(error);
   data.days[key]=day;
  }else if(msg.type==='now'){
   if(msg.date!==key)throw Error('O dia mudou. Reabra a extensão antes de registrar.');
   const day={...data.days[key],work:data.settings.work,lunch:data.settings.lunch};
   const field=FIELDS.find(f=>day[f]==null);
   if(!field||field!==msg.field)throw Error('As marcações mudaram. Confira o horário antes de continuar.');
   day[field]=Math.floor(now);const error=validate(day,now);if(error)throw Error(error);data.days[key]=day;
  }else throw Error('Comando inválido.');
  await save(data);await tick();return read();
 }).then(data=>respond({ok:true,data}),e=>respond({ok:false,error:e.message}));
 return true;
});
