import {DEFAULTS,FIELDS,LABELS,dateKey,minute,parse,time,duration,calculate,reminder} from './core.js';
const $=id=>document.getElementById(id);
let data={settings:{...DEFAULTS},days:{},sent:{}},key=dateKey(),busy=false,loaded=false,toastTimer;
async function request(type,extra={}){const r=await chrome.runtime.sendMessage({type,...extra});if(!r?.ok)throw Error(r?.error||'Não foi possível acessar os dados.');return r.data;}
function feedback(message){$('feedback').textContent=message;$('feedback').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('feedback').hidden=true,6000);}
async function action(fn){if(busy)return;busy=true;$('register').disabled=true;try{await fn();}catch(e){feedback(e.message);}finally{busy=false;render();}}
function render(){
 const now=new Date();if(key!==dateKey(now)){key=dateKey(now);}
 const day=data.days[key]??{},s=data.settings,c=calculate(day,s,minute(now));
 $('date').textContent=now.toLocaleDateString('pt-BR',{weekday:'short',day:'numeric',month:'long'});$('clock').textContent=now.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
 $('goalLabel').textContent=`META · ${duration(c.goal)}`;
 $('status').textContent={idle:'Aguardando entrada',lunch:'Pausa para almoço',working:c.remaining<=0?'Meta cumprida':'Em expediente',done:'Dia encerrado'}[c.state];
 $('leaveLabel').textContent=c.state==='done'?'SAÍDA REGISTRADA':c.estimated?'SAÍDA ESTIMADA':'SUA SAÍDA PREVISTA';
 $('leave').textContent=time(c.state==='done'?day.exit:c.leave);
 $('countdown').textContent=c.state==='idle'?'Um novo dia, no seu ritmo.':c.state==='done'?`Saldo do dia: ${c.balance<0?'−':'+'}${duration(Math.abs(c.balance))}`:c.state==='lunch'?'Contagem pausada. Aproveite seu intervalo.':c.remaining<=0?`Meta cumprida · ${duration(c.balance)} além da jornada`:`${duration(c.remaining)} de trabalho para completar o dia`;
 $('progress').style.width=`${c.progress*100}%`;$('percent').textContent=`${Math.floor(c.progress*100)}%`;$('worked').textContent=`${duration(c.worked)} trabalhadas`;$('remaining').textContent=duration(c.remaining);$('lunch').textContent=duration(c.lunch);$('lunchLabel').textContent=day.lunchBack!=null?'Almoço realizado':c.state==='lunch'?'Tempo no almoço':'Almoço planejado';
 const notices=[];const r=reminder(day,s,minute(now),now.getDay());if(r)notices.push(r.message);
 if(day.lunchBack!=null&&c.lunch<60)notices.push('Intervalo menor que 1h. Confira suas marcações; o cálculo preserva os horários reais.');
 if(c.state==='lunch'&&c.lunch>c.planned)notices.push('O almoço passou do previsto. A saída se ajustará ao seu retorno real.');
 if(c.estimated&&c.state==='working')notices.push(`Previsão com ${duration(c.planned)} de almoço. Confirme as pausas para calcular a saída real.`);
 if(c.state==='done'&&c.balance<0)notices.push(`O dia terminou com ${duration(-c.balance)} faltantes.`);
 $('notice').hidden=!notices.length;$('notice').textContent=notices.join(' ');
 $('status').dataset.state=c.state;
 FIELDS.forEach((f,i)=>{const input=$(`mark-${f}`),el=input.closest('.mark');el.className=`mark ${day[f]!=null?'complete':c.next===f?'next':''}`;el.querySelector('.step').textContent=day[f]!=null?'✓':i+1;if(document.activeElement!==input)input.value=day[f]!=null?time(day[f]):'';});
 $('register').textContent=c.next?['Sinalizar entrada','Sinalizar saída para almoço','Sinalizar volta do almoço','Sinalizar saída'][FIELDS.indexOf(c.next)]+' · '+time(Math.floor(minute(now))):'✓ Jornada encerrada';$('register').disabled=busy||!loaded||!c.next;
}
function fillSettings(){const s=data.settings;$('workSetting').value=time(s.work);$('lunchSetting').value=time(s.lunch);$('entrySetting').value=s.entry;$('lunchAtSetting').value=s.lunchAt;$('notificationsSetting').checked=s.notifications;document.querySelectorAll('[name=weekday]').forEach(i=>i.checked=s.days.includes(Number(i.value)));}
function history(){const entries=Object.entries(data.days).sort(([a],[b])=>b.localeCompare(a));$('historyList').replaceChildren();if(!entries.length){const p=document.createElement('p');p.className='empty';p.textContent='Seu histórico começa com a primeira entrada.';$('historyList').append(p);}for(const [date,day] of entries){const c=calculate(day,data.settings,day.exit??day.lunchBack??day.lunchOut??day.entry);const el=document.createElement('article');el.className='history-item';const head=document.createElement('header');const title=document.createElement('span');title.textContent=date.split('-').reverse().join('/');const balance=document.createElement('span');balance.className='balance';balance.textContent=day.exit!=null?`${c.balance<0?'−':'+'}${duration(Math.abs(c.balance))}`:'Em aberto';head.append(title,balance);const p=document.createElement('p');p.textContent=FIELDS.map((f,i)=>`${['Entrada','Almoço','Retorno','Saída'][i]} ${time(day[f])}`).join(' · ');el.append(head,p);$('historyList').append(el);}}
document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>{document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!==button.dataset.tab);document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b===button));if(button.dataset.tab==='history')history();});
['D','S','T','Q','Q','S','S'].forEach((name,i)=>{const label=document.createElement('label');label.textContent=name;const input=document.createElement('input');input.type='checkbox';input.name='weekday';input.value=i;input.setAttribute('aria-label',['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'][i]);label.append(input);$('weekdays').append(label);});
FIELDS.forEach((f,i)=>{
 const el=document.createElement('label');el.className='mark';
 const step=document.createElement('span');step.className='step';
 const label=document.createElement('span');label.textContent=['Entrada','Almoço','Retorno','Saída'][i];
 const input=document.createElement('input');input.type='text';input.inputMode='numeric';input.maxLength=5;input.placeholder='—:—';input.id=`mark-${f}`;input.className='mark-time';input.autocomplete='off';input.setAttribute('aria-label',`${LABELS[i]}: editar horário`);input.title='Digite HH:MM. Enter salva; Esc cancela. Para apagar, comece pela última marcação.';
 let original=null,editingDate=key;
 input.onfocus=()=>{original=data.days[key]?.[f]??null;editingDate=key;input.select();};
 input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();input.blur();}if(e.key==='Escape'){input.value=original==null?'':time(original);input.blur();}};
 input.onblur=()=>{
  let text=input.value.trim();if(/^\d{4}$/.test(text))text=text.slice(0,2)+':'+text.slice(2);
  const value=parse(text);
  if(text&&value===null){feedback('Use um horário válido no formato HH:MM.');render();return;}
  if(value===original){render();return;}
  if(busy){feedback('Aguarde o salvamento anterior e tente novamente.');render();return;}
  action(async()=>{data=await request('mark',{date:editingDate,field:f,value,expected:original});feedback('Horário atualizado.');});
 };
 el.append(step,label,input);$('marks').append(el);
});
$('register').onclick=()=>{const day=data.days[key]??{},field=FIELDS.find(f=>day[f]==null);action(async()=>{data=await request('now',{date:key,field});feedback('Horário salvo no seu acompanhamento.');});};
$('settingsForm').onsubmit=e=>{e.preventDefault();action(async()=>{const settings={work:parse($('workSetting').value),lunch:parse($('lunchSetting').value),entry:$('entrySetting').value,lunchAt:$('lunchAtSetting').value,notifications:$('notificationsSetting').checked,days:[...document.querySelectorAll('[name=weekday]:checked')].map(i=>Number(i.value))};data=await request('settings',{settings});feedback('Ajustes salvos.');});};
$('test').onclick=()=>action(async()=>{await request('test');feedback('Notificação enviada. Se não aparecer, confira as notificações do Chrome no sistema.');});
$('expand').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('popup.html')});
$('export').onclick=()=>{const rows=[['Data','Entrada','Saida almoco','Retorno','Saida','Meta minutos','Trabalhado minutos','Saldo minutos']];for(const [date,day] of Object.entries(data.days).sort()){const c=calculate(day,data.settings,day.exit??day.lunchBack??day.lunchOut??day.entry);rows.push([date,...FIELDS.map(f=>day[f]==null?'':time(day[f])),c.goal,day.exit==null?'':c.worked,day.exit==null?'':c.balance]);}const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=`jornada-${dateKey()}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.data){data=changes.data.newValue;render();if(!$('history').hidden)history();}});
try{data=await request('read');loaded=true;fillSettings();render();setInterval(render,1000);}catch(e){feedback('Não foi possível carregar a extensão. '+e.message);}
