export const DEFAULTS = {work:528, lunch:90, entry:'08:00', lunchAt:'12:00', days:[1,2,3,4,5], notifications:true};
export const FIELDS = ['entry','lunchOut','lunchBack','exit'];
export const LABELS = ['Entrada','Saída para almoço','Volta do almoço','Saída'];
export function dateKey(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function minute(d=new Date()){return d.getHours()*60+d.getMinutes()+d.getSeconds()/60;}
export function parse(s){if(!/^\d{2}:\d{2}$/.test(s||''))return null;const [h,m]=s.split(':').map(Number);return h<24&&m<60?h*60+m:null;}
export function time(n){if(n==null)return '—:—';const v=Math.round(n);return `${String(Math.floor(v/60)%24).padStart(2,'0')}:${String(v%60).padStart(2,'0')}${v>=1440?' (+1 dia)':''}`;}
export function duration(n){n=Math.max(0,Math.floor(n));return `${String(Math.floor(n/60)).padStart(2,'0')}h ${String(n%60).padStart(2,'0')}m`;}
export function settingsValid(s){return Number.isInteger(s.work)&&s.work>0&&s.work<=960&&Number.isInteger(s.lunch)&&s.lunch>=60&&s.lunch<=360&&parse(s.entry)!==null&&parse(s.lunchAt)!==null&&parse(s.lunchAt)>parse(s.entry)&&Array.isArray(s.days)&&s.days.length>0&&s.days.every(x=>Number.isInteger(x)&&x>=0&&x<=6)&&typeof s.notifications==='boolean';}
export function validate(day,now=null){
 let previous=-1,missing=false;
 for(const field of FIELDS){const v=day[field];if(v==null){missing=true;continue;}if(missing)return 'Preencha as marcações anteriores primeiro.';if(!Number.isInteger(v)||v<0||v>=1440)return 'Use um horário válido.';if(v<=previous)return 'Os horários precisam estar em ordem crescente.';if(now!==null&&v>Math.floor(now))return 'Uma marcação não pode estar no futuro.';previous=v;}
 return null;
}
export function calculate(day={},settings=DEFAULTS,now=minute()){
 const goal=day.work??settings.work, planned=day.lunch??settings.lunch;
 const {entry:e,lunchOut:o,lunchBack:b,exit:x}=day;
 let worked=0,leave=null,lunch=planned,state='idle';
 if(e!=null){
  state=x!=null?'done':b!=null?'working':o!=null?'lunch':'working';
  const end=x??now;
  worked=Math.max(0,(o??end)-e)+(b!=null?Math.max(0,end-b):0);
  lunch=b!=null?b-o:o!=null?Math.max(0,now-o):planned;
  leave=e+goal+(b!=null?b-o:o!=null?Math.max(planned,now-o):planned);
 }
 return {goal,planned,worked,lunch,leave,state,remaining:Math.max(0,goal-worked),balance:worked-goal,progress:Math.min(1,worked/goal),estimated:e!=null&&b==null,next:FIELDS.find(f=>day[f]==null)};
}
export function reminder(day,settings,now,weekday){
 if(!settings.days.includes(weekday)||day.exit!=null)return null;
 const c=calculate(day,settings,now);
 if(day.entry==null&&now>=parse(settings.entry)&&now<parse(settings.lunchAt))return {id:'entry',title:'Vamos começar?',message:'Confira o ponto oficial e sinalize sua entrada aqui.'};
 if(day.entry!=null&&day.lunchOut==null&&now>=parse(settings.lunchAt))return {id:'lunch',title:'Hora do almoço',message:'Lembre de bater o ponto de saída para o almoço.'};
 if(day.lunchOut!=null&&day.lunchBack==null&&now>=day.lunchOut+c.planned)return {id:'back',title:'Hora de voltar',message:'Seu intervalo planejado terminou. Confira o ponto e sinalize o retorno.'};
 if(day.lunchBack!=null){const left=c.leave-now;const stage=left<=0?0:left<=10?10:left<=20?20:null;if(stage!==null)return {id:`exit-${c.leave}-${stage}`,title:stage?`Faltam ${stage} minutos`:'Jornada cumprida',message:stage?`Sua saída está prevista para ${time(c.leave)}. Prepare-se para bater o ponto.`:'Você completou sua jornada. Lembre de bater o ponto de saída.'};}
 return null;
}
